# Document Reviewer — ZCode 文档选区批注插件

在 ZCode 会话侧栏打开工作区文档，直接选中文字添加批注，最后把所有待发送批注一次性交给**当前主 Agent**，由 Agent 按批注修改原始文件并逐条反馈。

支持 **Markdown（渲染 / 源码双视图）**、**TXT**、**PDF（pdf.js 文本层选中、缩放、高亮）**，中文排版与 CJK PDF 均已实测。

---

## 功能

| 能力 | 说明 |
| --- | --- |
| 文件浏览 | 递归扫描工作区，支持 `.md` / `.markdown` / `.txt` / `.pdf`，可筛选、刷新 |
| Markdown | 渲染视图（标题、列表、表格、代码块）与源码视图切换；两种视图均可精确选区 |
| TXT | 按块渲染，长文档使用 `content-visibility` 分块优化 |
| PDF | pdf.js 渲染、自适应宽度、缩放（40%–300%）、文本层选择、跨页选区自动拆分 |
| 批注 | 浮动「添加批注」、多行输入、`Ctrl+Enter` 保存、`Esc` 取消 |
| 批注管理 | 右侧列表、定位、编辑、单条删除、批量清空、删除撤销提示 |
| 高亮联动 | Markdown/TXT 用 `<mark>` 高亮，PDF 用页面归一化矩形覆盖；点击高亮打开对应批注 |
| 多文件 | 不同文档的批注合并计数、合并发送 |
| 持久化 | 批注写入插件数据目录；切换文件、关闭面板、重载页面后未发送批注仍在 |
| 冲突检测 | 文件内容变化后自动重定位锚点；无法重定位时标记「位置待核对」；发送前再次校验哈希 |
| 发送 | 优先 `sendMessage`（`ui/message`）；宿主不支持时降级为 `updateModelContext`；两者都不可用时提供合并内容复制 |
| 主题 | 跟随 ZCode 宿主深色 / 浅色主题 |

---

## 架构

```text
document-reviewer/
├── .zcode-plugin/plugin.json     # 插件清单：MCP 服务 + UI surface
├── skills/document-reviewer/     # 告诉 Agent 何时调用 show_reviewer
├── src/
│   ├── shared/                   # 类型与消息模板（前后端共享）
│   ├── server/                   # MCP stdio 服务
│   │   ├── index.ts              # 工具、资源、面板 HTML 注册
│   │   ├── workspace.ts          # 工作区路径校验、文件读取、哈希
│   │   └── store.ts              # 批注持久化（插件数据目录）
│   └── ui/                       # React 面板
│       ├── index.tsx             # ext-apps 连接与握手
│       ├── App.tsx               # 布局、状态、批注、发送
│       ├── bridge.ts             # callServerTool / readServerResource / sendMessage 封装
│       ├── markdown.tsx          # 带源码偏移映射的 Markdown 渲染器
│       ├── TextView.tsx          # TXT / Markdown 源码视图
│       ├── PdfViewer.tsx         # pdf.js 渲染、文本层选区、高亮
│       └── text.ts               # 锚点、重定位、DOM 选区换算
├── build.mjs                     # esbuild 打包（server + 单文件 panel.html）
├── scripts/
│   ├── stage.mjs                 # 生成本地 marketplace
│   ├── validate.mjs              # 清单与产物校验
│   ├── smoke.mjs                 # 真实 MCP stdio 冒烟测试
│   └── mock-host.mjs             # 浏览器端 MCP Apps 模拟宿主（开发/验收用）
└── test-fixtures/                # 测试文档
```

### 关键设计

- **页面不直接读文件。** 所有文件访问都经过 MCP 服务的 `open_document` / 分片资源接口。
- **路径校验。** 传入路径先 `path.resolve`，再做 `realpath`，拒绝工作区之外的绝对路径、`..` 穿越和符号链接逃逸；只允许白名单扩展名。
- **只读。** 插件只读文档，不提供任何写文件工具；实际修改由主 Agent 用 ZCode 原生编辑工具完成。
- **锚点。** Markdown/TXT 记录字符区间、起止行号、前后 60 字上下文；PDF 记录页码、文本块索引、块内字符偏移与归一化矩形。
- **重定位。** 文件哈希变化后先按偏移核对，再在 ±500 字范围内按原文搜索；仍找不到才标记为待核对，不会把旧选区硬套到新内容。
- **发送去重。** 发送成功后批注状态变为 `sent` 并写入 `batchId`，底部计数立即归零；重复点击不会重发同一批。

---

## Windows 安装

前置：Node.js 24+、ZCode Desktop（支持 Plugin UI 的版本）。以下命令在 PowerShell 或 Git Bash 中执行。

### 1. 构建

```powershell
cd "E:\1-研究生\00.ZCode_Project\01.ZCode设置\document-reviewer"
npm install
npm run typecheck
npm run build
npm run validate
npm run stage
```

`npm run stage` 会生成：

```text
dist\local-marketplace\
├── marketplace.json
└── plugins\document-reviewer\   # 可直接安装的完整插件
```

### 2. 安装到 ZCode

如果 `zcode` 命令不在 PATH，用 ZCode 自带的 CLI：

```powershell
$CLI = "D:\Program Files\ZCode\resources\glm\zcode.cjs"

node $CLI plugins marketplace add "E:\1-研究生\00.ZCode_Project\01.ZCode设置\document-reviewer\dist\local-marketplace" --scope user
node $CLI plugins install document-reviewer@document-reviewer-local --scope user
node $CLI plugins enable document-reviewer@document-reviewer-local --scope user
node $CLI plugins list --json
```

确认输出中 `document-reviewer@document-reviewer-local` 的 `enabled` 为 `true`，`diagnostics` 为空。

### 3. 在新会话中使用

**已启动的会话不会热加载新插件。** 按 `Ctrl+N` 新建会话（或重启 ZCode），然后任选一种方式：

- 对 Agent 说：「打开文档批注面板」/「审阅 `docs/report.md`」；
- 点击输入区的「插件」按钮，选择 **Document Reviewer**。

面板打开后：左侧选文件 → 选中文字 → 「添加批注」→ 重复 → 底部「批量发送」。

### 4. 卸载

```powershell
node $CLI plugins uninstall document-reviewer@document-reviewer-local --scope user
node $CLI plugins marketplace remove document-reviewer-local --scope user
```

插件数据位于：

```text
C:\Users\<你>\.zcode\cli\plugins\data\document-reviewer@document-reviewer-local\
```

卸载插件时该目录默认一并删除。

---

## 开发与测试

| 命令 | 作用 |
| --- | --- |
| `npm run typecheck` | TypeScript 严格模式检查 |
| `npm run build` | 打包 `dist/server.mjs`、`dist/panel.html`、pdf.js worker 与 CJK 资源 |
| `npm run validate` | 校验清单、`ui://` 资源、MIME、内联脚本与体积上限 |
| `node scripts/smoke.mjs [--pdf sample.pdf]` | 用真实 MCP stdio 客户端调用全部工具、读取分片与面板资源 |
| `MOCK_PORT=8791 node scripts/mock-host.mjs` | 启动 MCP Apps 模拟宿主，浏览器打开 `http://127.0.0.1:8791/` |
| `MOCK_NO_MESSAGE=1 MOCK_PORT=8792 node scripts/mock-host.mjs` | 模拟宿主不支持 `ui/message`，验证降级到 `updateModelContext` |

模拟宿主实现了 `ui/initialize`、`tools/call`、`resources/read`、`ui/message`、`ui/update-model-context` 等真实 JSON-RPC 消息，用于在浏览器里做端到端回归。

---

## 已执行的验收测试（2026-10-19）

环境：Windows 10.0.26200、Node 24.13.0、ZCode 0.17.0、Chrome（DevTools 自动化）。

| # | 测试 | 结果 |
| --- | --- | --- |
| 1 | 真实 ZCode 运行时加载插件并调用 `show_reviewer` | 通过（headless CLI 实跑，返回工作区根目录与 `surface=reviewer`） |
| 2 | 打开 Markdown 并渲染标题、段落、列表、表格、代码块 | 通过 |
| 3 | 在三个不同位置选中文字各加一条批注 | 通过，底部显示「这 3 条批注」 |
| 4 | 批量发送 | 通过，宿主收到 `role=user`、`content=[{type:"text"}]` 的单条消息 |
| 5 | 消息包含文件、位置、原文、前后文、修改意见与处理要求 | 通过（预览与实收内容逐字核对） |
| 6 | 发送后计数归零、不会重复发送 | 通过 |
| 7 | 切换文件后未发送批注保留 | 通过 |
| 8 | 重新加载面板后未发送批注恢复 | 通过（从插件数据目录恢复，并自动打开上次文档） |
| 9 | 文件内容变化后旧选区处理 | 通过：偏移变化时自动重定位并标记「位置待核对」；发送前再次检测哈希并弹出确认 |
| 10 | 宿主无 `ui/message` 能力时降级 | 通过：调用 `ui/update-model-context`，提示手动确认，批注保持待发送 |
| 11 | PDF 打开、缩放、文本层选择、批注、高亮 | 通过（16 页 11 MB PDF；120% 缩放后高亮重新定位） |
| 12 | 中文 PDF 文本层 | 通过（中文标题与段落可选中、可批注） |
| 13 | Markdown 源码视图选区 | 通过（选区含 `**` 等源码标记，锚点精确） |
| 14 | TXT 选区与 `Ctrl+Enter` 保存 | 通过 |

**未完成的真机验证：** ZCode 桌面端的自动化键盘输入被系统输入通道拦截，未能在真实面板里用脚本完成「点击 → 输入批注 → 发送」全流程；该流程已在模拟宿主中用同一份 `dist/panel.html`、同一套 MCP 服务完整跑通，真实宿主侧的工具加载与调用已单独验证。建议首次安装后手工点一遍发送，确认输入区出现消息。

---

## 已知限制

1. **仅桌面本地工作区**。按官方约定，UI 面板用于 ZCode Desktop 本地工作区；Web、手机和远程工作区只会保留普通 MCP 工具。
2. **只读**。插件不会写回原文件，必须由 Agent 执行修改。
3. **格式**：`.md` / `.markdown` / `.txt` / `.pdf`。不解析 DOCX。
4. **单文件 100 MiB**。PDF 按 1 MiB 分片读取，面板资源单次读取上限 8 MiB；超大 PDF 首次打开会明显变慢。
5. **扫描版 PDF 无文本层**，只能看渲染结果，无法选中文字。本插件不做 OCR。
6. **PDF 选区跨页**时会自动拆成多条批注（每页一条，共用同一修改意见）。
7. **锚点精度**：Markdown 渲染视图通过源码扫描映射偏移；极少数经过转义或实体编码的文本无法精确映射时会退化为块级锚点，此时仍能添加批注，但重定位可靠性下降。
8. **已发送记录**只保留状态与 `batchId`，不追踪 Agent 是否真的完成修改（ZCode 没有回传处理结果的接口）。
9. **批注持久化按工作区隔离**；换工作区看不到另一工作区的草稿。
10. **主题**跟随宿主；不提供手动切换。

---

## DOCX 扩展建议（未实现）

评估过 `mammoth`（DOCX → HTML）方案，结论是**第一版不做**：

- Mammoth 输出的是 HTML，丢失 OOXML 的原始字符偏移，无法像 Markdown 那样建立精确锚点；只能退化为「原文 + 前后文 + 出现序号」的文本匹配，跨修订、批注、页眉页脚时容易错位。
- ZCode 官方 `documents` 插件已经提供 Word 查看与「引用段落」能力，`docx` 技能负责修改；再做一个弱定位的 DOCX 预览价值有限。
- 若后续要做，建议顺序：
  1. 服务端用 `mammoth` 转 HTML，同时保留 `docx` 原文；
  2. 锚点只记「规范化原文 + 段前/段后上下文 + 出现序号」，不承诺字符偏移；
  3. 发送时明确告诉 Agent「DOCX 选区为文本匹配定位，需自行核对」；
  4. 修改仍交给 Agent 的 `docx` 技能或 python-docx，插件保持只读。

其他可扩展格式同理：`.html`（可直接复用选区模型）、`.tex`（源码视图）、`.csv`（表格选区）。优先做 HTML/TeX 的收益高于 DOCX。

---

## 安全说明

- 插件不向任何第三方服务器上传文档；页面不加载 CDN、字体或远程脚本。
- 页面运行在宿主沙箱中，无 Node / 任意文件系统权限；文件读取只能通过本插件 MCP 服务的受控接口。
- 所有路径都做工作区范围与 `realpath` 校验。
- 发送的内容仅包括：工作区相对路径、文件哈希前缀、批注原文与上下文、用户修改意见。不包含文件全文。
- 插件安装即授予代码执行信任；发布前请审查 `dist/server.mjs` 与 `dist/panel.html`。

---

## 依赖

| 包 | 版本 | 用途 |
| --- | --- | --- |
| `@modelcontextprotocol/ext-apps` | 2.0.0 | MCP Apps 页面桥（官方锁定版本） |
| `@modelcontextprotocol/sdk` | 1.29.0 | MCP stdio 服务端 |
| `react` / `react-dom` | 19.2.0 | 面板 UI |
| `markdown-it` | 14.1.0 | Markdown 解析（自行渲染以保留源码偏移） |
| `pdfjs-dist` | 5.4.296 | PDF 渲染与文本层 |
| `esbuild` | 0.25.12 | 打包 |

PDF 的 CMaps、标准字体与 wasm 随包分发，运行时不联网。
