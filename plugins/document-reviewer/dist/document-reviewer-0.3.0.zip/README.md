# Document Reviewer — ZCode 文档选区批注插件

在 ZCode 对话里**内联**打开文档（也可以固定到侧栏），直接选中文字添加批注，最后把所有待发送批注一次性交给**当前主 Agent**，由 Agent 按批注修改原始文件并逐条反馈。

支持 **Markdown（渲染 / 源码双视图）**、**TXT**、**PDF（pdf.js 文本层选中、缩放、高亮）**、**DOCX（Mammoth 转 Markdown 预览）**，中文排版与 CJK PDF 均已实测。

---

## 功能

| 能力 | 说明 |
| --- | --- |
| 打开方式 | 默认在对话中内联显示（工具结果卡片），不占插件页；顶部「展开到侧栏」可切到固定侧栏 |
| 文件浏览 | 递归扫描工作区，支持 `.md` / `.markdown` / `.txt` / `.pdf` / `.docx`，可筛选、刷新 |
| Markdown | 渲染视图（标题、列表、表格、代码块）与源码视图切换；两种视图均可精确选区 |
| TXT | 按块渲染，长文档使用 `content-visibility` 分块优化 |
| PDF | pdf.js 渲染、自适应宽度、缩放（40%–300%）、文本层选择、跨页选区自动拆分 |
| DOCX | Mammoth 转 Markdown 预览；批注按原文文本 + 前后文 + 出现序号定位 |
| 批注 | 浮动「添加批注」、多行输入、`Ctrl+Enter` 保存、`Esc` 取消 |
| 批注管理 | 右侧列表、定位、编辑、单条删除、批量清空、删除撤销提示 |
| 高亮联动 | Markdown/TXT/DOCX 用 `<mark>` 高亮，PDF 用页面归一化矩形覆盖；点击高亮打开对应批注 |
| 多文件 | 不同文档的批注合并计数、合并发送 |
| 持久化 | 批注写入插件数据目录；切换文件、关闭面板、重载页面后未发送批注仍在 |
| 冲突检测 | 文件内容变化后自动重定位锚点；无法重定位时标记「位置待核对」；发送前再次校验哈希 |
| 发送 | 优先 `sendMessage`（`ui/message`）；宿主不支持时降级为 `updateModelContext`；两者都不可用时提供合并内容复制 |
| 主题 | 跟随 ZCode 宿主深色 / 浅色主题 |

---

## 两种打开方式

- **内联（默认）**：对 Agent 说「打开文档批注面板」或「审阅 `docs/report.md`」。Agent 调用 `show_reviewer` / `open_document`，面板作为工具结果卡片出现在对话里，不需要去插件列表找入口。
- **侧栏**：用户明确要固定面板时，Agent 调用 `show_reviewer_sidebar`；也可以在插件菜单里打开。内联模式下顶部有「展开到侧栏」按钮（走 `ui/request-display-mode`）。

---

## 架构

```text
document-reviewer/
├── .zcode-plugin/plugin.json     # 插件清单：MCP 服务 + UI surface
├── skills/document-reviewer/     # 告诉 Agent 何时内联打开、如何处理 DOCX
├── src/
│   ├── shared/                   # 类型与消息模板（前后端共享）
│   ├── server/                   # MCP stdio 服务
│   │   ├── index.ts              # 工具、资源、面板 HTML 注册
│   │   ├── workspace.ts          # 工作区路径校验、文件读取、哈希
│   │   ├── docx.ts               # Mammoth DOCX → 干净 Markdown
│   │   └── store.ts              # 批注持久化（插件数据目录）
│   └── ui/                       # React 面板
│       ├── index.tsx             # ext-apps 连接与握手
│       ├── App.tsx               # 布局、状态、批注、发送
│       ├── bridge.ts             # callServerTool / readServerResource / sendMessage 封装
│       ├── markdown.tsx          # 带源码偏移映射的 Markdown 渲染器
│       ├── TextView.tsx          # TXT / Markdown 源码视图
│       ├── PdfViewer.tsx         # pdf.js 渲染、文本层选区、高亮
│       └── text.ts               # 锚点、重定位、DOCX 出现序号、DOM 选区换算
├── build.mjs                     # esbuild 打包（server + 单文件 panel.html）
├── scripts/
│   ├── stage.mjs                 # 生成本地 marketplace
│   ├── validate.mjs              # 清单与产物校验
│   ├── smoke.mjs                 # 真实 MCP stdio 冒烟测试（含 DOCX/工具 meta）
│   └── mock-host.mjs             # 浏览器端 MCP Apps 模拟宿主（开发/验收用）
└── test-fixtures/                # 测试文档
```

### 关键设计

- **页面不直接读文件。** 所有文件访问都经过 MCP 服务的 `open_document` / 分片资源接口。
- **路径校验。** 传入路径先 `path.resolve`，再做 `realpath`，拒绝工作区之外的绝对路径、`..` 穿越和符号链接逃逸；只允许白名单扩展名。
- **只读。** 插件只读文档，不提供任何写文件工具；实际修改由主 Agent 用 ZCode 原生编辑工具完成。
- **锚点。** Markdown/TXT 记录字符区间、起止行号、前后 60 字上下文；PDF 记录页码、文本块索引、块内字符偏移与归一化矩形；DOCX 在预览文本上记录同样的区间，并额外记录**段落序号**和**原文第几次出现**。
- **重定位。** 文件哈希变化后先按偏移核对，再在 ±500 字范围内按原文搜索；仍找不到才标记为待核对，不会把旧选区硬套到新内容。
- **发送去重。** 发送成功后批注状态变为 `sent` 并写入 `batchId`，底部计数立即归零；重复点击不会重发同一批。
- **DOCX 边界。** Word 没有稳定的字符偏移，Mammoth 只负责生成预览；发送时会明确告诉 Agent「按文本匹配定位，请在 Word 原文中核对」，Agent 必须用 `docx` 技能或 python-docx 重新定位。

---

## Windows 安装

前置：Node.js 24+、ZCode Desktop（支持 Plugin UI 的版本）。以下命令在 PowerShell 或 Git Bash 中执行。

### 1. 构建

```powershell
cd "E:\1-研究生\00.ZCode_Project\01.ZCode设置\document-reviewer"
npm install
npm run typecheck
npm run build
npm run validate
npm run stage
```

`npm run stage` 会生成：

```text
dist\local-marketplace\
├── marketplace.json
└── plugins\document-reviewer\   # 可直接安装的完整插件
```

### 2. 安装到 ZCode

如果 `zcode` 命令不在 PATH，用 ZCode 自带的 CLI：

```powershell
$CLI = "D:\Program Files\ZCode\resources\glm\zcode.cjs"

node $CLI plugins marketplace add "E:\1-研究生\00.ZCode_Project\01.ZCode设置\document-reviewer\dist\local-marketplace" --scope user
node $CLI plugins install document-reviewer@document-reviewer-local --scope user
node $CLI plugins enable document-reviewer@document-reviewer-local --scope user
node $CLI plugins list --json
```

确认输出中 `document-reviewer@document-reviewer-local` 的 `enabled` 为 `true`，`diagnostics` 为空。

### 3. 在新会话中使用

**已启动的会话不会热加载新插件。** 按 `Ctrl+N` 新建会话（或重启 ZCode），然后直接说：

```
打开文档批注面板
```

面板会作为工具结果**内联出现在对话中**。也可以说「审阅 `document-reviewer/test-fixtures/sample.docx`」直接打开某个文件。

需要固定侧栏时，说「用侧栏打开文档批注面板」，或点面板顶部的「展开到侧栏」。

### 4. 卸载

```powershell
node $CLI plugins uninstall document-reviewer@document-reviewer-local --scope user
node $CLI plugins marketplace remove document-reviewer-local --scope user
```

插件数据位于：

```text
C:\Users\<你>\.zcode\cli\plugins\data\document-reviewer@document-reviewer-local\
```

卸载插件时该目录默认一并删除。

---

## 开发与测试

| 命令 | 作用 |
| --- | --- |
| `npm run typecheck` | TypeScript 严格模式检查 |
| `npm run build` | 打包 `dist/server.mjs`、`dist/panel.html`、pdf.js worker 与 CJK 资源 |
| `npm run validate` | 校验清单、`ui://` 资源、MIME、内联脚本与体积上限 |
| `node scripts/smoke.mjs [--pdf zh.pdf]` | 用真实 MCP stdio 客户端调用工具、读取分片、检查内联/侧栏工具 `_meta`、转换 DOCX |
| `MOCK_PORT=8791 node scripts/mock-host.mjs` | 启动 MCP Apps 模拟宿主，浏览器打开 `http://127.0.0.1:8791/` |
| `MOCK_INLINE=1 MOCK_PORT=8791 node scripts/mock-host.mjs` | 模拟内联展示，验证「展开到侧栏」按钮与 `ui/request-display-mode` |
| `MOCK_NO_MESSAGE=1 MOCK_PORT=8792 node scripts/mock-host.mjs` | 模拟宿主不支持 `ui/message`，验证降级到 `updateModelContext` |

模拟宿主实现了 `ui/initialize`、`tools/call`、`resources/read`、`ui/message`、`ui/update-model-context`、`ui/request-display-mode` 等真实 JSON-RPC 消息。

---

## 已执行的验收测试（2026-10-19）

环境：Windows 10.0.26200、Node 24.13.0、ZCode 0.17.0、Chrome（DevTools 自动化）。

| # | 测试 | 结果 |
| --- | --- | --- |
| 1 | 真实 ZCode 运行时加载插件并调用 `show_reviewer` | 通过（headless CLI 实跑，返回工作区根目录与 `surface=reviewer`） |
| 2 | 工具 `_meta` 区分内联与侧栏 | 通过：`show_reviewer` 无 `surface`，`show_reviewer_sidebar` 带 `surface=reviewer` |
| 3 | 内联模式「展开到侧栏」 | 通过：宿主收到 `ui/request-display-mode {mode:"fullscreen"}` |
| 4 | 打开 Markdown 并渲染标题、段落、列表、表格、代码块 | 通过 |
| 5 | 在三个不同位置选中文字各加一条批注 | 通过，底部显示「这 3 条批注」 |
| 6 | 批量发送 | 通过，宿主收到 `role=user`、`content=[{type:"text"}]` 的单条消息 |
| 7 | 消息包含文件、位置、原文、前后文、修改意见与处理要求 | 通过（预览与实收内容逐字核对） |
| 8 | 发送后计数归零、不会重复发送 | 通过 |
| 9 | 切换文件后未发送批注保留 | 通过 |
| 10 | 重新加载面板后未发送批注恢复 | 通过（从插件数据目录恢复，并自动打开上次文档） |
| 11 | 文件内容变化后旧选区处理 | 通过：偏移变化时自动重定位并标记「位置待核对」；发送前再次检测哈希并弹出确认 |
| 12 | 宿主无 `ui/message` 能力时降级 | 通过：调用 `ui/update-model-context`，提示手动确认，批注保持待发送 |
| 13 | PDF 打开、缩放、文本层选择、批注、高亮 | 通过（16 页 11 MB PDF；120% 缩放后高亮重新定位） |
| 14 | 中文 PDF 文本层 | 通过（中文标题与段落可选中、可批注） |
| 15 | Markdown 源码视图选区 | 通过（选区含 `**` 等源码标记，锚点精确） |
| 16 | TXT 选区与 `Ctrl+Enter` 保存 | 通过 |
| 17 | DOCX 打开与预览 | 通过（33k 字符的审稿回复 DOCX；标题、段落、列表、加粗正常渲染） |
| 18 | DOCX 选区、批注与发送 | 通过，消息含「DOCX 转换预览 第 5 行（字符 84–124，第 3 段，原文第 1 次出现）」及 Word 核对提示 |

**未完成的真机验证：** ZCode 桌面端的自动化键盘输入被系统输入通道拦截，未能在真实面板里用脚本完成「点击 → 输入批注 → 发送」全流程；该流程已在模拟宿主中用同一份 `dist/panel.html`、同一套 MCP 服务完整跑通，真实宿主侧的工具加载与调用已单独验证。建议首次安装后手工点一遍发送，确认输入区出现消息。

---

## 已知限制

1. **仅桌面本地工作区**。按官方约定，UI 面板用于 ZCode Desktop 本地工作区；Web、手机和远程工作区只会保留普通 MCP 工具。
2. **只读**。插件不会写回原文件，必须由 Agent 执行修改。
3. **格式**：`.md` / `.markdown` / `.txt` / `.pdf` / `.docx`。DOCX 只读正文，页眉页脚、脚注、批注、修订痕迹和嵌入对象可能丢失。
4. **单文件 100 MiB**。PDF 按 1 MiB 分片读取，面板资源单次读取上限 8 MiB；超大 PDF 首次打开会明显变慢。
5. **扫描版 PDF 无文本层**，只能看渲染结果，无法选中文字。本插件不做 OCR。
6. **PDF 选区跨页**时会自动拆成多条批注（每页一条，共用同一修改意见）。
7. **DOCX 定位是弱锚点**：字符偏移只针对转换后的 Markdown 预览，不对应 Word 内部位置；同名表述较多时可能定位到错误段落。消息里会带段落序号、出现次数和前后文，并要求 Agent 核对。
8. **锚点精度**：Markdown 渲染视图通过源码扫描映射偏移；极少数经过转义或实体编码的文本无法精确映射时会退化为块级锚点。
9. **已发送记录**只保留状态与 `batchId`，不追踪 Agent 是否真的完成修改（ZCode 没有回传处理结果的接口）。
10. **批注持久化按工作区隔离**；换工作区看不到另一工作区的草稿。
11. **主题**跟随宿主；不提供手动切换。

---

## DOCX 实现与后续建议

已实现：Mammoth 的浏览器构建（`mammoth/mammoth.browser.js`，避免 Node `require` 与 ESM 打包冲突）生成 HTML，再用 `node-html-parser` 转成**干净 Markdown**（标题、段落、列表、表格、加粗/斜体、图片占位），由现有 Markdown 渲染器显示。图片不内嵌 base64，避免大文件。

后续可改进：

1. **保留原样式**：Mammoth 的样式映射（`styleMap`）可以把 Word 的标题/引用样式映射得更准。
2. **修订与批注**：用 python-docx 读取 `w:ins`/`w:del`/`w:comment`，在预览中标记修订，但工作量较大。
3. **精确锚点**：解析 OOXML 段落 ID（`w14:paraId`）与文本节点偏移，把锚点绑定到段落 ID，可比纯文本匹配稳得多；这是下一步最值得做的。
4. **表格与页眉页脚**：当前表格转 GFM，页眉页脚未纳入预览。
5. **其他格式**：`.html` 可直接复用选区模型；`.tex` 适合源码视图；`.csv` 适合表格选区。

---

## 安全说明

- 插件不向任何第三方服务器上传文档；页面不加载 CDN、字体或远程脚本。
- 页面运行在宿主沙箱中，无 Node / 任意文件系统权限；文件读取只能通过本插件 MCP 服务的受控接口。
- 所有路径都做工作区范围与 `realpath` 校验。
- 发送的内容仅包括：工作区相对路径、文件哈希前缀、批注原文与上下文、用户修改意见。不包含文件全文。
- DOCX 转换在本地 MCP 服务进程内完成，不联网。
- 插件安装即授予代码执行信任；发布前请审查 `dist/server.mjs` 与 `dist/panel.html`。

---

## 依赖

| 包 | 版本 | 用途 |
| --- | --- | --- |
| `@modelcontextprotocol/ext-apps` | 2.0.0 | MCP Apps 页面桥（官方锁定版本） |
| `@modelcontextprotocol/sdk` | 1.29.0 | MCP stdio 服务端 |
| `react` / `react-dom` | 19.2.0 | 面板 UI |
| `markdown-it` | 14.1.0 | Markdown 解析（自行渲染以保留源码偏移） |
| `pdfjs-dist` | 5.4.296 | PDF 渲染与文本层 |
| `mammoth` | 1.13.0 | DOCX → HTML（浏览器构建，避免动态 require） |
| `node-html-parser` | 最新 | Mammoth HTML → 干净 Markdown |
| `esbuild` | 0.25.12 | 打包 |

PDF 的 CMaps、标准字体与 wasm 随包分发，运行时不联网。
